import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lock, Copy, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import QRCode from "qrcode";

export default function Payment() {
  const [, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const orderId = searchParams.get("orderId") || "";

  const [qrCodeImage, setQrCodeImage] = useState<string>("");
  const [timeLeft, setTimeLeft] = useState(300);

  const { data: order, isLoading } = trpc.checkout.getOrder.useQuery(
    { orderId },
    { enabled: !!orderId }
  );

  useEffect(() => {
    if (order?.pixCode) {
      QRCode.toDataURL(order.pixCode, {
        width: 300,
        margin: 2,
      }).then(setQrCodeImage);
    }
  }, [order?.pixCode]);

  useEffect(() => {
    if (order?.expiresAt) {
      const expirationTime = new Date(order.expiresAt).getTime();
      
      const updateTimer = () => {
        const now = Date.now();
        const remaining = Math.max(0, Math.floor((expirationTime - now) / 1000));
        setTimeLeft(remaining);
        
        if (remaining <= 0) {
          toast.error("Tempo expirado! Faça um novo pedido.");
        }
      };

      updateTimer();
      const timer = setInterval(updateTimer, 1000);

      return () => clearInterval(timer);
    }
  }, [order?.expiresAt]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(cents / 100);
  };

  const copyPixCode = () => {
    if (order?.pixCode) {
      navigator.clipboard.writeText(order.pixCode);
      toast.success("Código PIX copiado!");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">Carregando...</div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">Pedido não encontrado</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/tiktok-logo.png" alt="TikTok Shop" className="h-12" />
          </div>
          <div className="flex items-center gap-2">
            <img src="/badge-seguro.png" alt="Pagamento 100% Seguro" className="h-8 opacity-90" />
          </div>
        </div>
      </header>

      {/* Timer Banner */}
      <div className="bg-gray-900 text-white py-4">
        <div className="container text-center">
          <p className="font-semibold">Tempo restante para pagamento: {formatTime(timeLeft)}</p>
          <p className="text-sm mt-1">Complete o pagamento antes que o tempo expire.</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Payment Instructions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center text-2xl">Pagamento via PIX</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* QR Code */}
              <div className="flex flex-col items-center">
                {qrCodeImage && (
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <img src={qrCodeImage} alt="QR Code PIX" className="w-64 h-64" />
                  </div>
                )}
                <p className="text-sm text-gray-600 mt-4 text-center">
                  Escaneie o QR Code com o app do seu banco
                </p>
              </div>

              {/* Divider */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-gray-50 text-gray-500">ou</span>
                </div>
              </div>

              {/* PIX Code */}
              <div>
                <label className="block text-sm font-medium mb-2">Código PIX Copia e Cola</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={order.pixCode || ""}
                    readOnly
                    className="flex-1 px-3 py-2 border rounded-md bg-gray-100 text-sm font-mono"
                  />
                  <Button onClick={copyPixCode} variant="outline" size="icon">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-600 mt-2">
                  Copie o código acima e cole no app do seu banco
                </p>
              </div>

              {/* Payment Value */}
              <div className="bg-primary/10 border border-primary rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Valor a pagar:</span>
                  <span className="text-2xl font-bold text-primary">
                    {formatCurrency(order.productPrice)}
                  </span>
                </div>
              </div>

              {/* Instructions */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                  Como pagar com PIX:
                </h3>
                <ol className="text-sm space-y-2 ml-7 list-decimal">
                  <li>Abra o app do seu banco</li>
                  <li>Escolha a opção PIX</li>
                  <li>Escaneie o QR Code ou cole o código</li>
                  <li>Confirme o pagamento</li>
                  <li>Pronto! Seu pedido será confirmado automaticamente</li>
                </ol>
              </div>

              {/* Order Details */}
              <div className="border-t pt-4">
                <h3 className="font-semibold mb-3">Detalhes do Pedido</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Pedido:</span>
                    <span className="font-mono">{order.orderId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Produto:</span>
                    <span>{order.productName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Cliente:</span>
                    <span>{order.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-semibold">
                      {order.status === "pending" ? "Aguardando Pagamento" : order.status}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

