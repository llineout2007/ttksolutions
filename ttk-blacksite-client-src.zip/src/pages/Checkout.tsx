import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lock, User, Package, CreditCard, Star } from "lucide-react";
import { toast } from "sonner";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const productId = searchParams.get("product") || "";

  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerDocument: "",
    customerPhone: "",
    cep: "",
    street: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
  });

  const { data: product, isLoading: loadingProduct } = trpc.checkout.getProduct.useQuery(
    { productId },
    { enabled: !!productId }
  );

  const createOrderMutation = trpc.checkout.createOrder.useMutation({
    onSuccess: (data) => {
      setLocation(`/payment?orderId=${data.orderId}`);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar pedido");
    },
  });

  const checkCepMutation = trpc.checkout.checkCep.useMutation({
    onSuccess: (data) => {
      setFormData((prev) => ({
        ...prev,
        street: data.address || "",
        neighborhood: data.neighborhood || "",
        city: data.city || "",
        state: data.state || "",
      }));
      toast.success(`CEP encontrado: ${data.city} - ${data.state}`);
    },
    onError: () => {
      toast.error("CEP não encontrado");
    },
  });

  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(cents / 100);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const formatCPFCNPJ = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    }
    return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
  };

  const formatCEP = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    return numbers.replace(/(\d{5})(\d{3})/, "$1-$2");
  };

  const handleCepBlur = () => {
    if (formData.cep.replace(/\D/g, "").length === 8) {
      checkCepMutation.mutate({ cep: formData.cep });
    }
  };

  const handleContinue = () => {
    if (currentStep === 1) {
      if (!formData.customerName || !formData.customerEmail || !formData.customerDocument || !formData.customerPhone) {
        toast.error("Preencha todos os campos de identificação");
        return;
      }
      setCurrentStep(2);
    } else if (currentStep === 2) {
      setCurrentStep(3);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.cep || !formData.street || !formData.number || !formData.neighborhood || !formData.city || !formData.state) {
      toast.error("Preencha todos os campos de endereço");
      return;
    }

    createOrderMutation.mutate({
      productId,
      ...formData,
    });
  };

  if (loadingProduct) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">Carregando...</div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">Produto não encontrado</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/tiktok-logo.png" alt="TikTok Shop" className="h-12" />
          </div>
          <div className="flex items-center gap-2">
            <img src="/badge-seguro.png" alt="Pagamento 100% Seguro" className="h-8 opacity-90" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Side - Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Step 1: Identification */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold ${currentStep >= 1 ? 'bg-black' : 'bg-gray-300'}`}>
                      1
                    </div>
                    <span>Identifique-se</span>
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-2">
                    Informe seus dados para identificar seu perfil, histórico de compras, notificação de pedidos e carrinho de compras.
                  </p>
                </CardHeader>
                {currentStep === 1 && (
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="name">Nome completo</Label>
                      <Input
                        id="name"
                        placeholder="ex.: Maria da Almeida Cruz"
                        value={formData.customerName}
                        onChange={(e) => handleInputChange("customerName", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="seu@email.com"
                        value={formData.customerEmail}
                        onChange={(e) => handleInputChange("customerEmail", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="document">CPF</Label>
                      <Input
                        id="document"
                        placeholder="000.000.000-00"
                        value={formatCPFCNPJ(formData.customerDocument)}
                        onChange={(e) => handleInputChange("customerDocument", e.target.value.replace(/\D/g, ""))}
                        maxLength={18}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Celular / WhatsApp</Label>
                      <div className="flex gap-2">
                        <div className="flex items-center gap-2 px-3 py-2 border rounded-md bg-gray-50 w-20">
                          <span className="text-sm">🇧🇷</span>
                          <span className="text-sm">+55</span>
                        </div>
                        <Input
                          id="phone"
                          placeholder="(00) 00000-0000"
                          value={formatPhone(formData.customerPhone)}
                          onChange={(e) => handleInputChange("customerPhone", e.target.value.replace(/\D/g, ""))}
                          maxLength={15}
                          className="flex-1"
                        />
                      </div>
                    </div>
                    <Button
                      type="button"
                      onClick={handleContinue}
                      className="w-full bg-black hover:bg-gray-800 text-white py-6"
                    >
                      Continuar →
                    </Button>
                  </CardContent>
                )}
              </Card>

              {/* Step 2: Payment */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold ${currentStep >= 2 ? 'bg-black' : 'bg-gray-300'}`}>
                      2
                    </div>
                    <span>Pagamento</span>
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-2">
                    Forma de pagamento selecionada para este pedido.
                  </p>
                </CardHeader>
                {currentStep === 2 && (
                  <CardContent className="space-y-4">
                    <div className="border-2 border-[#00D09C] rounded-lg p-6 bg-[#00D09C]/5 hover:bg-[#00D09C]/10 transition-colors">
                      <div className="flex items-center justify-center mb-3">
                        <img src="/pix-logo.jpeg" alt="PIX" className="h-16" />
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-semibold text-gray-800 mb-1">Pagamento via PIX</p>
                        <p className="text-xs text-gray-600">Aprovação instantânea • 100% seguro</p>
                      </div>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-xs text-blue-800">
                        🔒 <strong>Pagamento seguro:</strong> Após confirmar o pedido, você receberá o QR Code PIX para realizar o pagamento de forma rápida e segura.
                      </p>
                    </div>
                    <Button
                      type="button"
                      onClick={handleContinue}
                      className="w-full bg-black hover:bg-gray-800 text-white py-6"
                    >
                      Continuar →
                    </Button>
                  </CardContent>
                )}
              </Card>

              {/* Step 3: Delivery */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold ${currentStep >= 3 ? 'bg-black' : 'bg-gray-300'}`}>
                      3
                    </div>
                    <span>Entrega</span>
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-2">
                    Informe o endereço completo para entrega do seu pedido.
                  </p>
                </CardHeader>
                {currentStep === 3 && (
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="cep">CEP *</Label>
                      <Input
                        id="cep"
                        placeholder="12345-000"
                        value={formatCEP(formData.cep)}
                        onChange={(e) => handleInputChange("cep", e.target.value.replace(/\D/g, ""))}
                        onBlur={handleCepBlur}
                        maxLength={9}
                      />
                      <p className="text-xs text-gray-500 mt-1">Digite o CEP para preencher automaticamente</p>
                    </div>
                    
                    <div>
                      <Label htmlFor="street">Rua/Avenida *</Label>
                      <Input
                        id="street"
                        placeholder="ex.: Avenida Paulista"
                        value={formData.street}
                        onChange={(e) => handleInputChange("street", e.target.value)}
                        disabled={checkCepMutation.isPending}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="number">Número *</Label>
                        <Input
                          id="number"
                          placeholder="123"
                          value={formData.number}
                          onChange={(e) => handleInputChange("number", e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="complement">Complemento</Label>
                        <Input
                          id="complement"
                          placeholder="Apto 45"
                          value={formData.complement}
                          onChange={(e) => handleInputChange("complement", e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="neighborhood">Bairro *</Label>
                      <Input
                        id="neighborhood"
                        placeholder="ex.: Bela Vista"
                        value={formData.neighborhood}
                        onChange={(e) => handleInputChange("neighborhood", e.target.value)}
                        disabled={checkCepMutation.isPending}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="city">Cidade *</Label>
                        <Input
                          id="city"
                          placeholder="ex.: São Paulo"
                          value={formData.city}
                          onChange={(e) => handleInputChange("city", e.target.value)}
                          disabled={checkCepMutation.isPending}
                        />
                      </div>
                      <div>
                        <Label htmlFor="state">Estado *</Label>
                        <Input
                          id="state"
                          placeholder="SP"
                          value={formData.state}
                          onChange={(e) => handleInputChange("state", e.target.value.toUpperCase())}
                          maxLength={2}
                          disabled={checkCepMutation.isPending}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                      <p className="text-xs text-green-800">
                        🚚 <strong>Entrega rápida:</strong> Seu pedido será enviado em até 2 dias úteis após a confirmação do pagamento.
                      </p>
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full bg-black hover:bg-gray-800 text-white py-6"
                      disabled={createOrderMutation.isPending}
                    >
                      {createOrderMutation.isPending ? "Processando..." : "Finalizar Pedido →"}
                    </Button>
                  </CardContent>
                )}
              </Card>
            </form>
          </div>

          {/* Right Side - Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">RESUMO</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Produto</span>
                    <span className="font-semibold">{formatCurrency(product.price)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold border-t pt-4">
                    <span>Total</span>
                    <span className="text-primary">{formatCurrency(product.price)}</span>
                  </div>
                  
                  <div className="border-t pt-4">
                    <div className="flex gap-3">
                      {product.imageUrl && (
                        <img src={product.imageUrl} alt={product.name} className="w-16 h-16 object-cover rounded" />
                      )}
                      <div className="flex-1">
                        <p className="text-sm font-medium">{product.name}</p>
                        <p className="text-xs text-gray-600 mt-1">Qtd.: 1</p>
                        <p className="text-sm font-semibold mt-1">{formatCurrency(product.price)}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Testimonials */}
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <div className="flex items-start gap-2">
                      <img src="/correios.png" alt="Correios" className="w-12 h-12 object-contain" />
                      <div className="flex-1">
                        <p className="text-sm font-semibold">Correios</p>
                        <p className="text-xs text-gray-600">
                          Você receberá o código de rastreio via e-mail em até 5 dias úteis para acompanhar a entrega de sua compra. Possuímos um sistema de entrega inteligente. Rastreie sua compra para todo Brasil.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 border-t pt-4">
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <div className="flex items-start gap-2">
                      <img src="/garantia.png" alt="Garantia" className="w-12 h-12 object-contain" />
                      <div className="flex-1">
                        <p className="text-sm font-semibold">Garantia de Reembolso</p>
                        <p className="text-xs text-gray-600">
                          Você tem até 30 dias para realizar trocas das devoluções conforme a Política de Reembolso.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 border-t pt-4">
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <div className="flex items-start gap-2">
                      <img src="/reclameaqui.png" alt="Reclame Aqui" className="w-12 h-12 object-contain" />
                      <div className="flex-1">
                        <p className="text-sm font-semibold">Reclame Aqui</p>
                        <p className="text-xs text-gray-600">
                          10.422 avaliações positivas para esta empresa.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-12 py-8">
        <div className="container text-center space-y-4">
          <p className="text-sm font-semibold">Formas de pagamento</p>
          <div className="flex justify-center">
            <img src="/pix-logo.jpeg" alt="PIX" className="h-12" />
          </div>
          <p className="text-sm font-semibold mt-2">TikTok Shop</p>
          <div className="text-xs text-gray-600 space-y-1 mt-2">
            <p>CNPJ: 27.485.970/0001-44</p>
            <p>Email: tiktokshop@contato.com</p>
            <p className="flex justify-center gap-4 mt-2">
              <a href="#" className="hover:underline">Termos de uso</a>
              <span>|</span>
              <a href="#" className="hover:underline">Trocas e devoluções</a>
              <span>|</span>
              <a href="#" className="hover:underline">Política de Privacidade</a>
            </p>
          </div>
          <div className="flex justify-center gap-8 mt-4">
            <img src="/selo-ssl.png" alt="Seguro Certificado SSL" className="h-12" />
            <img src="/selo-pagamentos.png" alt="Pagamentos Seguros" className="h-12" />
          </div>
        </div>
      </footer>
    </div>
  );
}

