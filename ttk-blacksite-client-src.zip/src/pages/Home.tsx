import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Star, Heart, Share2, ShoppingCart, ChevronLeft, ChevronRight, Package, RotateCcw } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [activeTab, setActiveTab] = useState("overview");
  const [timeLeft, setTimeLeft] = useState({ hours: 4, minutes: 55, seconds: 0 });

  const productImages = [
    "/product6.webp",
    "/product3.webp",
    "/product1.webp",
    "/product4.webp",
    "/product5.webp",
    "/product2.webp",
  ];

  // Timer countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleBuyNow = () => {
    setLocation("/checkout?product=72b0294c-b11c-11f0-b47c-46da4690ad53");
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % productImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + productImages.length) % productImages.length);
  };

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <button className="text-gray-600">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <span className="text-sm text-gray-500">Pesquisar</span>
        <div className="flex items-center gap-4 text-gray-600">
          <Share2 className="w-5 h-5" />
          <div className="relative">
            <ShoppingCart className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">0</span>
          </div>
        </div>
      </header>

      {/* Product Images */}
      <div className="relative">
        <div className="relative h-[350px] bg-gray-100">
          <img
            src={productImages[currentImageIndex]}
            alt="Produto"
            className="w-full h-full object-contain"
          />
          <div className="absolute bottom-4 right-4 bg-black/60 text-white px-2 py-1 rounded-full text-xs">
            {currentImageIndex + 1}/{productImages.length}
          </div>
          <button
            onClick={prevImage}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/70"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextImage}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/70"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Price Section */}
      <div className="p-4 space-y-2">
        <div className="flex items-center gap-2">
          <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded">-78%</span>
          <span className="text-3xl font-bold text-gray-900">R$ 67,90</span>
          <span className="text-sm text-gray-400 line-through">R$ 619,90</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-red-500 font-semibold">⚡ Oferta Relâmpago</span>
          <span className="text-gray-600">
            Termina em {String(timeLeft.hours).padStart(2, '0')}:{String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
          </span>
        </div>
      </div>

      {/* Product Title */}
      <div className="px-4 pb-3 border-b border-gray-200">
        <h1 className="text-base font-normal text-gray-900 mb-2">
          Patinete Elétrico Scooter De Alumínio Com Bluetooth 30km/h
        </h1>
        <div className="flex items-center gap-2 text-sm">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-gray-900">4.7</span>
            <span className="text-gray-500">(204)</span>
          </div>
          <span className="text-gray-500">4473 vendidos</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="sticky top-[57px] z-40 bg-white border-b border-gray-200">
        <div className="flex">
          <button
            onClick={() => setActiveTab("overview")}
            className={`flex-1 py-3 text-sm font-medium ${
              activeTab === "overview"
                ? "text-gray-900 border-b-2 border-gray-900"
                : "text-gray-500"
            }`}
          >
            Visão geral
          </button>
          <button
            onClick={() => setActiveTab("reviews")}
            className={`flex-1 py-3 text-sm font-medium ${
              activeTab === "reviews"
                ? "text-gray-900 border-b-2 border-gray-900"
                : "text-gray-500"
            }`}
          >
            Avaliações
          </button>
          <button
            onClick={() => setActiveTab("description")}
            className={`flex-1 py-3 text-sm font-medium ${
              activeTab === "description"
                ? "text-gray-900 border-b-2 border-gray-900"
                : "text-gray-500"
            }`}
          >
            Descrição
          </button>
          <button
            onClick={() => setActiveTab("recommendations")}
            className={`flex-1 py-3 text-sm font-medium ${
              activeTab === "recommendations"
                ? "text-gray-900 border-b-2 border-gray-900"
                : "text-gray-500"
            }`}
          >
            Recomendações
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="p-4">
        {activeTab === "overview" && (
          <div className="space-y-4">
            <div className="flex items-start gap-3 py-3 border-b border-gray-200">
              <Package className="w-5 h-5 text-gray-600 mt-0.5" />
              <div>
                <div className="font-medium text-sm">Receba até 31 de out.</div>
                <div className="text-xs text-gray-500 line-through">Taxa de envio: R$ 20,90</div>
              </div>
            </div>
            <div className="flex items-start gap-3 py-3">
              <RotateCcw className="w-5 h-5 text-gray-600 mt-0.5" />
              <div className="text-sm text-gray-700">
                Devoluções gratuitas em 30 dias • Cancelamento fácil
              </div>
            </div>

            <div className="pt-4">
              <h3 className="font-semibold text-base mb-3">Avaliações dos clientes (207)</h3>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl font-bold">4.7</span>
                <span className="text-sm text-gray-500">/5</span>
                <div className="flex items-center gap-0.5 ml-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
              </div>

              {/* Sample Reviews */}
              <div className="space-y-4">
                <div className="border-b border-gray-200 pb-4">
                  <div className="flex items-start gap-3 mb-2">
                    <img src="/perfil2.jpg" alt="Perfil" className="w-8 h-8 rounded-full object-cover" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">C**I* S**t**</span>
                        <span className="text-xs text-teal-500">há 2 horas</span>
                      </div>
                      <div className="flex items-center gap-0.5 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mb-1">Item: Patinete Elétrico Scooter De Alumínio Com Bluetooth 30km/h</p>
                      <p className="text-sm text-gray-700 mb-2">
                        Chegou bem rapidinho, fiquei um pouco com medo porque não tinha comentários, mas foi excelente, meu marido amou, podem comprar sem medo!
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <img src="/re1.png.jpg" alt="Review" className="w-full h-40 object-cover rounded" />
                        <img src="/re2.pnv.jpg" alt="Review" className="w-full h-40 object-cover rounded" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <div className="flex items-start gap-3 mb-2">
                    <img src="/perfil1.jpg" alt="Perfil" className="w-8 h-8 rounded-full object-cover" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">B**t** O**v**a</span>
                        <span className="text-xs text-teal-500">há 6 horas</span>
                      </div>
                      <div className="flex items-center gap-0.5 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mb-1">Item: Patinete Elétrico Scooter De Alumínio Com Bluetooth 30km/h</p>
                      <p className="text-sm text-gray-700 mb-2">
                        Produto sensacional! A estrutura de alumínio é muito boa e aguenta bem meu peso. O bluetooth é um diferencial legal para controlar pelo app.
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <img src="/re3.png.jpg" alt="Review" className="w-full h-40 object-cover rounded" />
                        <img src="/re4.png.jpg" alt="Review" className="w-full h-40 object-cover rounded" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "reviews" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl font-bold">4.7</span>
              <span className="text-sm text-gray-500">/5</span>
              <div className="flex items-center gap-0.5 ml-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
            </div>

            <div className="space-y-4">
              {[
                {
                  name: "A** P**I* S**u*",
                  time: "há 18 horas",
                  comment: "Chegou rápido e Acho que é original",
                  images: ["/re6.png.jpg"],
                  avatar: "/perfil3.jpg",
                },
                {
                  name: "P**r** R**g**s",
                  time: "há 14 horas",
                  comment: "Muito bom o produto venho certinho",
                  images: ["/re7.png.jpg", "/re8.png.jpg", "/re9.png.jpg"],
                  avatar: "/perfil4.jpg",
                },
                {
                  name: "C**I* S**t**",
                  time: "há 2 horas",
                  comment: "Chegou bem rapidinho, fiquei um pouco com medo porque não tinha comentários, mas foi excelente, meu marido amou, podem comprar sem medo!",
                  images: ["/re1.png.jpg", "/re2.pnv.jpg"],
                  avatar: "/perfil2.jpg",
                },
                {
                  name: "B**t** O**v**a",
                  time: "há 6 horas",
                  comment: "Produto sensacional! A estrutura de alumínio é muito boa e aguenta bem meu peso. O bluetooth é um diferencial legal para controlar pelo app.",
                  images: ["/re3.png.jpg", "/re4.png.jpg"],
                  avatar: "/perfil1.jpg",
                },
              ].map((review, index) => (
                <div key={index} className="border-b border-gray-200 pb-4">
                  <div className="flex items-start gap-3">
                    <img src={review.avatar} alt="Perfil" className="w-8 h-8 rounded-full object-cover" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{review.name}</span>
                        <span className="text-xs text-teal-500">{review.time}</span>
                      </div>
                      <div className="flex items-center gap-0.5 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mb-1">Item: Patinete Elétrico Scooter De Alumínio Com Bluetooth 30km/h</p>
                      <p className="text-sm text-gray-700 mb-2">{review.comment}</p>
                      <div className={`grid ${review.images.length === 3 ? 'grid-cols-3' : review.images.length === 2 ? 'grid-cols-2' : 'grid-cols-1'} gap-2`}>
                        {review.images.map((img, i) => (
                          <img key={i} src={img} alt="Review" className="w-full h-40 object-cover rounded" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "description" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between py-4 border-b border-gray-200">
              <div className="flex items-center gap-3">
                <img src="/belilogo.png" alt="Belifou Shop" className="w-12 h-12 rounded-full" />
                <div>
                  <div className="font-semibold text-sm">Belifou Shop</div>
                  <div className="text-xs text-gray-500">8745 vendido(s)</div>
                </div>
              </div>
              <Button variant="outline" size="sm" className="text-sm">
                Seguir
              </Button>
            </div>

            <div>
              <h3 className="font-semibold text-base mb-3">Descrição do Produto</h3>
              
              <div className="space-y-3 text-sm text-gray-700">
                <div>
                  <p className="font-semibold mb-2">Especificações Técnicas:</p>
                  <ul className="space-y-1 ml-4">
                    <li>Velocidade máxima: 30 km/h</li>
                    <li>Estrutura: Alumínio de alta resistência</li>
                    <li>Conectividade: Bluetooth integrado</li>
                    <li>Bateria de longa duração</li>
                    <li>Sistema de frenagem eficiente</li>
                    <li>Design dobrável para fácil transporte</li>
                  </ul>
                </div>

                <div>
                  <p className="font-semibold mb-2">Descrição:</p>
                  <p className="leading-relaxed">
                    O Patinete Elétrico Scooter é a solução perfeita para sua mobilidade urbana! Com estrutura robusta em alumínio e velocidade máxima de 30km/h, você chega ao seu destino de forma rápida, segura e sustentável.
                  </p>
                  <p className="leading-relaxed mt-2">
                    A conectividade Bluetooth permite que você controle diversas funções através do seu smartphone, proporcionando uma experiência moderna e conectada. Seu design dobrável facilita o transporte e armazenamento, ideal para quem precisa otimizar espaços.
                  </p>
                </div>

                <div>
                  <p className="font-semibold mb-2">Diferenciais:</p>
                  <ul className="space-y-1 ml-4">
                    <li>Economia de tempo no trânsito</li>
                    <li>Sustentável e ecológico</li>
                    <li>Fácil manuseio e controle</li>
                    <li>Baixo custo de manutenção</li>
                    <li>Ideal para percursos urbanos</li>
                  </ul>
                </div>

                <div className="pt-2">
                  <p className="font-semibold">Garantia:</p>
                  <p className="mt-1">
                    Em caso de demora na entrega, defeitos de fábrica, entrar em contato com o Suporte imediatamente para receber a devolução do dinheiro.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "recommendations" && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-32 h-32 mb-4 opacity-20">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <path d="M100 40 L140 80 L140 160 L60 160 L60 80 Z" fill="none" stroke="currentColor" strokeWidth="3"/>
                <circle cx="80" cy="60" r="3" fill="currentColor"/>
                <circle cx="120" cy="60" r="3" fill="currentColor"/>
                <path d="M80 80 Q100 90 120 80" fill="none" stroke="currentColor" strokeWidth="2"/>
                <path d="M70 40 L60 20 M130 40 L140 20" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
              </svg>
            </div>
            <p className="text-gray-500 text-sm">Ainda não temos recomendações para este produto</p>
          </div>
        )}
      </div>

      {/* Fixed Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg z-50">
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            className="flex-1 py-6 text-base font-medium border-gray-300"
          >
            Adicionar ao Carrinho
          </Button>
          <Button
            onClick={handleBuyNow}
            className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white font-bold py-6 text-base rounded-full"
          >
            Comprar Agora
          </Button>
        </div>
      </div>
    </div>
  );
}

